#include "GraczKomputerowy.hpp"
#include "Kasyno.hpp"

//GraczKomputerowy::GraczKomputerowy(Kasyno* _kasyno, const char* _nazwa, int _odwaga) : Gracz(_kasyno, _nazwa, true) {}



